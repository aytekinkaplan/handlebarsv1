# My Ghost Theme

This is a custom Ghost theme created by Aytekin Kaplan.

## Installation

1. Download the theme or clone the repository.
2. Upload the theme folder to your Ghost installation's `content/themes/` directory.
3. Activate the theme from the Ghost admin panel.

## Customization

You can customize the theme by editing the Handlebars templates, CSS files, and partials.

## License

This theme is open-source and licensed under the MIT License.
